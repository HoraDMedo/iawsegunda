<?php 
include('acceso_datos.php');

// ERORO SQLi

//$datos = $conexion_bd->query('SELECT * FROM Respuesta WHERE id_tema='. $_GET['id']);

//SELECT with WHERE shorter
$select = $conexion_bd->prepare("SELECT * FROM Respuesta WHERE id_tema = :ddd;");
$datos = $select->fetch($select->execute(array(':ddd' => $_GET["id"])));

//print_r($row);


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalle</title>
    <link rel="stylesheet" href="estilo.css">
</head>
<body>
    <div id="content">
       
    <h1> Listado de Comentarios del tema <?=$_GET['id']?></h1>
            <table>
                <tr>
                    <th>Titulo</th>
                    <th>Nombre</th>
                    <th>Contenido</th>
                 
                </tr>
               
                <?php foreach($select as $row2) { ?>
                <tr>
                
                    <td><?=$row2["titulo"]?></td>
                    <td><?=$row2["nombre"]?></td>
                    <td><?=$row2["contenido"]?></td>
   
                </tr>

                <?php } ?>          

                 
               
              


            </table>



    </div>
</body>
</html>